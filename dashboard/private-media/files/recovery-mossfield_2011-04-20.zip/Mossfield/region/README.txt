region/ not included in this export (over the 50 MB ticket attachment limit).
full copy: CHI-07:/srv/backup/mossfield/2011-04-20/region (6 files, r.-2.-1 .. r.0.0)
