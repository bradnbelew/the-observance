function the_hold:setup
tag @s add hold_started
tp @s 0.5 241 -15.5 180 0
gamemode adventure @s
clear @s
scoreboard players set @s hold_stage 0
