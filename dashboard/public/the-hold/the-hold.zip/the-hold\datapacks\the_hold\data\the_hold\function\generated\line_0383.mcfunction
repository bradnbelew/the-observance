setblock -23 241 96 minecraft:gray_bed[facing=east,part=foot]
