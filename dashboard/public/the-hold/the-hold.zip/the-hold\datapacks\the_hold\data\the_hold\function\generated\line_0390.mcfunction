setblock -22 241 114 minecraft:gray_bed[facing=east,part=head]
