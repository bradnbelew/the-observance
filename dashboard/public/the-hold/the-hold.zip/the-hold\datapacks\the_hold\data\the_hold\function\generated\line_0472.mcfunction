setblock 10 242 274 minecraft:soul_lantern
