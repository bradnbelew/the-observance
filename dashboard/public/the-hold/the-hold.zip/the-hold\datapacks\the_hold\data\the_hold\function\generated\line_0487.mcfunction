fill -24 240 306 24 240 354 deepslate_tiles
