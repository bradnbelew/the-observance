setblock 4 241 65 minecraft:soul_lantern
