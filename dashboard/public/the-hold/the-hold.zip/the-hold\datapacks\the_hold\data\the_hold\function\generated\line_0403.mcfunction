item replace block 0 241 119 container.2 with minecraft:paper[minecraft:item_name='"roll copied wrong"'] 1
