setblock -21 242 131 minecraft:black_candle[candles=1,lit=false]
