item replace block 0 241 165 container.0 with minecraft:kelp 6
