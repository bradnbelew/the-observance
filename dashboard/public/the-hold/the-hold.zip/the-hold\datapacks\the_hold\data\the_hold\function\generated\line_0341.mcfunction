setblock 20 242 38 minecraft:candle[candles=1,lit=true]
