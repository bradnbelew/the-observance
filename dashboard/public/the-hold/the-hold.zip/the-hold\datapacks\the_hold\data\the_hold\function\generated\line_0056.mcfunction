fill -34 258 -9 0 276 15 air
