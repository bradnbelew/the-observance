fill -34 220 66 0 238 90 air
