setblock 0 242 246 minecraft:barrel[facing=up]
