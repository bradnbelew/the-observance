setblock 4 242 108 minecraft:flower_pot
