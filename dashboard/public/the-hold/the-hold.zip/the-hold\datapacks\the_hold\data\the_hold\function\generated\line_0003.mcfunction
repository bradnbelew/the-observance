worldborder set 700
