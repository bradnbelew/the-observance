setblock 4 241 81 minecraft:soul_lantern
