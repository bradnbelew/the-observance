setblock -20 242 120 minecraft:lantern
