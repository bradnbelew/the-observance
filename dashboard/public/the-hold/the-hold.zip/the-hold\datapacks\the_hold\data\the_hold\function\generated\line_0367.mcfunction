fill -4 242 105 4 242 109 dark_oak_slab[type=top]
