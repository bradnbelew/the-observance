tag @s add hold_done
title @s times 20 80 40
title @s subtitle {text:"the address is not in this copy.",color:"dark_gray"}
title @s title {text:"SERVICE 1842",color:"gray",bold:true}
playsound minecraft:block.respawn_anchor.deplete master @s 0 242 320 0.4 0.5
