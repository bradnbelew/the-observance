fill -5 240 288 5 240 305 deepslate_tiles
