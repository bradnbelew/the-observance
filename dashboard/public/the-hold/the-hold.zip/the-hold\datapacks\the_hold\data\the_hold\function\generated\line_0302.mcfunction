setblock 0 242 -20 minecraft:soul_lantern
