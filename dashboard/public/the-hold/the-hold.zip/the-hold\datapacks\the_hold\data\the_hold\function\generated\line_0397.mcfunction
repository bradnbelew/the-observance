setblock -20 242 126 minecraft:lantern
