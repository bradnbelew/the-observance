fill -26 235 209 26 259 209 blackstone
