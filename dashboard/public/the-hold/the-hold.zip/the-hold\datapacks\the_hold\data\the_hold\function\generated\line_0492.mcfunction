fill -24 241 354 24 265 354 blackstone
