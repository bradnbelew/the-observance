fill -34 239 41 0 257 65 air
