setblock -12 239 174 minecraft:polished_basalt[axis=y]
