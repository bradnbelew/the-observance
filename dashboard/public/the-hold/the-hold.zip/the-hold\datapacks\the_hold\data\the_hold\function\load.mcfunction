function the_hold:setup
