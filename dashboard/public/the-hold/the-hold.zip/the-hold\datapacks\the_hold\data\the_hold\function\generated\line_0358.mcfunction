fill -26 241 83 26 255 83 tuff_bricks
