setblock -22 241 131 minecraft:black_carpet
