setblock 13 240 180 minecraft:blue_stained_glass
