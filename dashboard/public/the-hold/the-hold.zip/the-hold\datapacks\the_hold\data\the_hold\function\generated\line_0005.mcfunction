scoreboard objectives add hold_flags dummy
