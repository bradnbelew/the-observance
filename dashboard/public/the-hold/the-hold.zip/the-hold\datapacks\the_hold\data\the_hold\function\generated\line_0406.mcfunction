item replace block 6 241 119 container.0 with minecraft:bowl 6
