setblock -12 242 168 minecraft:soul_lantern
