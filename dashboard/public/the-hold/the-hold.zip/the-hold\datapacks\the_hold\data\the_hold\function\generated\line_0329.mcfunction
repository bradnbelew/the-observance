setblock -20 242 20 minecraft:candle[candles=1,lit=true]
