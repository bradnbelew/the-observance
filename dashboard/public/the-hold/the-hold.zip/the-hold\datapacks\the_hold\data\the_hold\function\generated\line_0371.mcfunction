setblock 0 243 106 minecraft:dark_oak_pressure_plate
