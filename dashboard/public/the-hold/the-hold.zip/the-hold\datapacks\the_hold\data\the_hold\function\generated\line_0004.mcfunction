scoreboard objectives add hold_stage dummy
