setblock 4 241 300 minecraft:soul_lantern
