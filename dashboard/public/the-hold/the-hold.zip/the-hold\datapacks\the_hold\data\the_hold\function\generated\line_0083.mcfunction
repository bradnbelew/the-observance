fill 1 277 -35 35 295 -10 air
