fill -26 256 83 26 256 133 blackstone
