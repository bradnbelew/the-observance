fill -24 266 306 24 266 354 blackstone
