setblock 10 241 274 minecraft:soul_soil
