setblock 20 242 14 minecraft:candle[candles=1,lit=true]
