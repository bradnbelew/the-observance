fill -3 241 15 3 241 21 deepslate_bricks
