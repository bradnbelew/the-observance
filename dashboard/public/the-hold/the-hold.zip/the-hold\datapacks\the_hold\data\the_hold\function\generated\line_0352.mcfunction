setblock -4 241 73 minecraft:soul_lantern
