setblock -20 242 96 minecraft:lantern
