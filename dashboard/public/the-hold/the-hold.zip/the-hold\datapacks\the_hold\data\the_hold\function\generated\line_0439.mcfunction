setblock -12 242 186 minecraft:soul_lantern
