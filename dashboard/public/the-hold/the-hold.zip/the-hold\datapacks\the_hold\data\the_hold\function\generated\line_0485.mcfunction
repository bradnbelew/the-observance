setblock -4 241 292 minecraft:soul_lantern
