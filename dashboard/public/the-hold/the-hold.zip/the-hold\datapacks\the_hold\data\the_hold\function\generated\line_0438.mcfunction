setblock -12 239 186 minecraft:polished_basalt[axis=y]
