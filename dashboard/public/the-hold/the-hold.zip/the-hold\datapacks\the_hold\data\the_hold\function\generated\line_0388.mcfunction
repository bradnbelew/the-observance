setblock -20 242 102 minecraft:lantern
