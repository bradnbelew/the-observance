fill -24 241 306 24 265 306 blackstone
