scoreboard players set #lamp hold_flags 0
