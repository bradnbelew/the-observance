fill -21 241 6 -21 247 10 deepslate_tiles
