setblock 0 241 119 minecraft:barrel[facing=up]
