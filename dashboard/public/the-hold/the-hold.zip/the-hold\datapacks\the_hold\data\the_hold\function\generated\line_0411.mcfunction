setblock -4 241 138 minecraft:soul_lantern
