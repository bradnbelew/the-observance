setblock -23 241 114 minecraft:gray_bed[facing=east,part=foot]
