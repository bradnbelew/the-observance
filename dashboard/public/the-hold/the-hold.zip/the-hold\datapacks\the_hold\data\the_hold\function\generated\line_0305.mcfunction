fill -22 241 0 -22 257 52 deepslate_bricks
