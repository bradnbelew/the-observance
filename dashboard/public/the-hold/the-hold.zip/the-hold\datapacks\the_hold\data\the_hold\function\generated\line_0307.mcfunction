fill -22 241 0 22 257 0 deepslate_bricks
