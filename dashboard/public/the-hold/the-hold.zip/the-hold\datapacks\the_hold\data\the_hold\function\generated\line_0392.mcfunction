setblock -23 241 120 minecraft:gray_bed[facing=east,part=foot]
