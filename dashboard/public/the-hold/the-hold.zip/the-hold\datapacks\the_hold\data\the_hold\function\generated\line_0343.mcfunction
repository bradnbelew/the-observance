fill -4 242 47 4 248 49 crying_obsidian
