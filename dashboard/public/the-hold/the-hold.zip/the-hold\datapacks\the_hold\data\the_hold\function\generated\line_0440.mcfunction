setblock -12 239 192 minecraft:polished_basalt[axis=y]
