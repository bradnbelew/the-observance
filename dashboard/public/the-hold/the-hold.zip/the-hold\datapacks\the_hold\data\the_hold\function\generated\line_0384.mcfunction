setblock -22 241 96 minecraft:gray_bed[facing=east,part=head]
