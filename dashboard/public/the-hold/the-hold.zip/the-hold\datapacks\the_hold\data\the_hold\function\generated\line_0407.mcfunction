item replace block 6 241 119 container.6 with minecraft:paper[minecraft:item_name='"seventh line struck through"'] 1
