setblock -12 239 162 minecraft:polished_basalt[axis=y]
