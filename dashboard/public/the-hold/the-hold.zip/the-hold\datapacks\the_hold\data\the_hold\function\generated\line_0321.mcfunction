setblock -20 242 8 minecraft:candle[candles=1,lit=true]
