setblock 4 241 230 minecraft:soul_lantern
