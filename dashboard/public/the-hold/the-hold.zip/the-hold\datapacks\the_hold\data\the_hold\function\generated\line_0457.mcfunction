fill -28 262 233 28 262 287 blackstone
