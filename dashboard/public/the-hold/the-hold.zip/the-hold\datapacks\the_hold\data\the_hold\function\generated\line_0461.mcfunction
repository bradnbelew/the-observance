fill -28 241 287 28 261 287 deepslate_tiles
