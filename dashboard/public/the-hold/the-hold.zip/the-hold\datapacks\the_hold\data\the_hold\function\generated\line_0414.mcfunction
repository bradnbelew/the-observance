fill -26 260 151 26 260 209 blackstone
