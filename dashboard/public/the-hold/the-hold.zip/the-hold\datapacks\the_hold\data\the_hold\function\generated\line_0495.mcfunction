fill -4 240 306 4 240 306 polished_deepslate
