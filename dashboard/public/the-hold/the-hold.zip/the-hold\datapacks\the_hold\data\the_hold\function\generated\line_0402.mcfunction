item replace block 0 241 119 container.1 with minecraft:bowl[minecraft:item_name='"one place left empty"'] 1
