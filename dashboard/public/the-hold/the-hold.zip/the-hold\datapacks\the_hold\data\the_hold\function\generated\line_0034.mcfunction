fill -170 120 -135 0 219 -135 black_concrete
