fill -20 241 22 -20 247 22 chiseled_deepslate
