item replace block -20 241 121 container.0 with minecraft:paper[minecraft:item_name='"six copies carried"'] 1
