fill 15 241 126 24 243 126 minecraft:barrel[facing=south]
