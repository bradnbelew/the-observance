fill -20 241 6 -20 247 6 chiseled_deepslate
