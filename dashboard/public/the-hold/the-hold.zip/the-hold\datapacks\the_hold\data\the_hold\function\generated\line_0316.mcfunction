fill -20 240 6 -18 240 42 deepslate_tiles
