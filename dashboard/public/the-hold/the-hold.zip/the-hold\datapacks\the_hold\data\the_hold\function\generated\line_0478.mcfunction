setblock -9 242 262 minecraft:soul_lantern
