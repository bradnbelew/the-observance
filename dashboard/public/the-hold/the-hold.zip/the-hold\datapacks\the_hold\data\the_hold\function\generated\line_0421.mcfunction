fill -4 240 151 4 240 151 polished_deepslate
