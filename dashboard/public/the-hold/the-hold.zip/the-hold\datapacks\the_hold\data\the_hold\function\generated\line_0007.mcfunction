scoreboard players set #built hold_flags 1
