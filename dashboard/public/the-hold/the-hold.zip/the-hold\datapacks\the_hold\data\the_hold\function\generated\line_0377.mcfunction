setblock -20 241 121 minecraft:barrel[facing=up]
