fill -20 241 10 -20 247 10 chiseled_deepslate
