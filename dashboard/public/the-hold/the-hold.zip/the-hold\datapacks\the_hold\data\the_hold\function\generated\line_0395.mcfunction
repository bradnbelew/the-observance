setblock -23 241 126 minecraft:gray_bed[facing=east,part=foot]
