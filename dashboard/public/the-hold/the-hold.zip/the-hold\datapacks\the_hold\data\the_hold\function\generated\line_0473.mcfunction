setblock 10 243 274 minecraft:black_candle[candles=1,lit=false]
