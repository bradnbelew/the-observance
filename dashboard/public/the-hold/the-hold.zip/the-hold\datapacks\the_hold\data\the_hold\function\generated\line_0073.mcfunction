fill -34 277 41 0 295 65 air
