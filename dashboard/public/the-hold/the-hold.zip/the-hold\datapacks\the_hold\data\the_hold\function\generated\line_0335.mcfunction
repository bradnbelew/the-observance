fill -20 241 30 -20 247 30 chiseled_deepslate
