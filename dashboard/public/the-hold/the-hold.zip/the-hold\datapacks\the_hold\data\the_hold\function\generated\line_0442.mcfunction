setblock -12 239 198 minecraft:polished_basalt[axis=y]
