setblock 0 242 106 minecraft:dark_oak_fence
