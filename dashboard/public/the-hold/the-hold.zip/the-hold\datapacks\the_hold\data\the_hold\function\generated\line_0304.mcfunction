fill -22 258 0 22 258 52 blackstone
