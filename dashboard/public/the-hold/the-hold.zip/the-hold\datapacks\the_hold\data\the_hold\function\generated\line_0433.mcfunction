setblock -12 242 162 minecraft:soul_lantern
