item replace block 0 241 165 container.1 with minecraft:seagrass 7
