execute as @a unless entity @s[x=-80,y=220,z=-40,dx=160,dy=80,dz=430] run function the_hold:spawn
execute as @a[tag=!hold_started] run function the_hold:spawn
execute as @a unless score @s hold_stage matches 0.. run scoreboard players set @s hold_stage 0
execute as @a[x=-18,y=240,z=0,dx=36,dy=24,dz=52] unless score @s hold_stage matches 1.. run function the_hold:triggers/record
execute as @a[x=-25,y=240,z=83,dx=50,dy=18,dz=50] unless score @s hold_stage matches 2.. run function the_hold:triggers/domestic
execute as @a[x=-24,y=234,z=151,dx=48,dy=30,dz=58] unless score @s hold_stage matches 3.. run function the_hold:triggers/water
execute as @a[x=-28,y=240,z=233,dx=56,dy=26,dz=54] unless score @s hold_stage matches 4.. run function the_hold:triggers/lamp_enter
execute as @a[x=-20,y=240,z=270,dx=40,dy=12,dz=20] if score #lamp hold_flags matches 1 run function the_hold:triggers/lamp_change
execute as @a[x=-22,y=240,z=306,dx=44,dy=45,dz=48] unless score @s hold_stage matches 5.. run function the_hold:triggers/final
