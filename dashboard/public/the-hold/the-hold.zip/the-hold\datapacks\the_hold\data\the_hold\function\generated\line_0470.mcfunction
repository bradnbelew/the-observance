setblock -10 241 274 minecraft:campfire[lit=true,facing=east]
