setblock -20 242 114 minecraft:lantern
