setblock -22 241 90 minecraft:gray_bed[facing=east,part=head]
