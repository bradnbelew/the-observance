setblock -12 242 174 minecraft:soul_lantern
