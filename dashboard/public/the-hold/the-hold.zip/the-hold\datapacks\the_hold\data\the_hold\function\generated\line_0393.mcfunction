setblock -22 241 120 minecraft:gray_bed[facing=east,part=head]
