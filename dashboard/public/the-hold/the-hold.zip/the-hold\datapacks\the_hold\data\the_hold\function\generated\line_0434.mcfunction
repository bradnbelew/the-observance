setblock -12 239 168 minecraft:polished_basalt[axis=y]
