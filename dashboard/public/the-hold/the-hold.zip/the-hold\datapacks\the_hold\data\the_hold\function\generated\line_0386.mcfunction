setblock -23 241 102 minecraft:gray_bed[facing=east,part=foot]
