setblock -2 242 106 minecraft:dark_oak_fence
