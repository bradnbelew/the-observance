setblock 4 241 146 minecraft:soul_lantern
