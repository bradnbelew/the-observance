setblock -10 241 250 minecraft:campfire[lit=true,facing=east]
