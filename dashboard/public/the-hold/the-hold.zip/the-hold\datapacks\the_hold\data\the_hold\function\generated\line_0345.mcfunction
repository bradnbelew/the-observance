setblock 0 242 18 minecraft:lectern[facing=south,has_book=true]
