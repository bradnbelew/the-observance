item replace block 0 241 165 container.2 with minecraft:paper[minecraft:item_name='"sella counted"'] 1
