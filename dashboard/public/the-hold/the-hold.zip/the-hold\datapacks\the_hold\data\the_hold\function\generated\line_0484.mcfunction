fill 6 241 288 6 241 305 iron_bars
