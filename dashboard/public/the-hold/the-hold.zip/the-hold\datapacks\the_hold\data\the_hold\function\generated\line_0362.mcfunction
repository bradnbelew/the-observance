fill -4 240 83 4 240 83 polished_deepslate
