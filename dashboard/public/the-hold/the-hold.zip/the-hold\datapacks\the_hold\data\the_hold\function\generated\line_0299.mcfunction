fill -8 241 -24 -8 242 -1 iron_bars
