setblock 14 235 180 minecraft:sea_lantern
