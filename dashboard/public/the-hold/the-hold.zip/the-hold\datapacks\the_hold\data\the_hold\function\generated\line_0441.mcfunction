setblock -12 242 192 minecraft:soul_lantern
