setblock 4 241 222 minecraft:soul_lantern
