item replace block 0 242 246 container.1 with minecraft:lantern[minecraft:item_name='"wrong cold lamp"'] 1
