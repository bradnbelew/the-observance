setblock -4 241 57 minecraft:soul_lantern
