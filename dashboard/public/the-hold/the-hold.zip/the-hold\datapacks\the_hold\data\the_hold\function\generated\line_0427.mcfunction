setblock 0 241 165 minecraft:barrel[facing=up]
