time set midnight
