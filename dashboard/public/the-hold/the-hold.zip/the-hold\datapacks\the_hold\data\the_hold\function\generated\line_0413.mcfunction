fill -26 234 151 26 234 209 blackstone
