fill -3 241 0 3 246 0 air
