setblock 6 241 119 minecraft:chest[facing=north]
