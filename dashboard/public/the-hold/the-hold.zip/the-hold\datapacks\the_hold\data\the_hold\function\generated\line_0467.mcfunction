setblock 0 241 260 minecraft:campfire[lit=true,facing=north]
