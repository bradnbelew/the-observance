fill -28 240 233 28 240 287 polished_blackstone_bricks
