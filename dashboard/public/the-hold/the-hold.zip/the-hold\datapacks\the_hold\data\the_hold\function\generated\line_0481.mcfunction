setblock 18 242 262 minecraft:soul_lantern
