fill -20 241 34 -20 247 34 chiseled_deepslate
