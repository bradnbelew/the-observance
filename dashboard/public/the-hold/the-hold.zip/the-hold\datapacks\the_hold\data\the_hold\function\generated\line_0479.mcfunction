setblock 0 242 262 minecraft:soul_lantern
