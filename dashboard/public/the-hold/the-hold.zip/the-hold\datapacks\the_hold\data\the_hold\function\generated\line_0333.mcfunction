setblock 20 242 26 minecraft:candle[candles=1,lit=true]
