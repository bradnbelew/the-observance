setblock 2 243 106 minecraft:dark_oak_pressure_plate
