setblock -20 242 32 minecraft:candle[candles=1,lit=true]
