setblock 0 241 -20 minecraft:lodestone
