setblock -23 241 90 minecraft:gray_bed[facing=east,part=foot]
