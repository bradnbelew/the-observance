setblock -12 242 198 minecraft:soul_lantern
