setblock -22 241 102 minecraft:gray_bed[facing=east,part=head]
