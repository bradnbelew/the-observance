setblock -22 241 126 minecraft:gray_bed[facing=east,part=head]
