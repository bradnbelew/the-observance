setblock 0 242 44 minecraft:black_candle[candles=1,lit=false]
