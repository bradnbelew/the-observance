setblock -4 241 214 minecraft:soul_lantern
