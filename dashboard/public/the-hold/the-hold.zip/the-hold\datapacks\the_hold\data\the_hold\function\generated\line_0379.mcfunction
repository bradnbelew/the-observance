item replace block -20 241 121 container.1 with minecraft:charcoal[minecraft:item_name='"lamp ash kept dry"'] 1
