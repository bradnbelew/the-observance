fill -26 235 151 -26 259 209 blackstone
