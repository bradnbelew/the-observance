setblock -20 242 90 minecraft:lantern
