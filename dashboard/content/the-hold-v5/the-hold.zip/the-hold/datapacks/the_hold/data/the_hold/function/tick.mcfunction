execute as @a[tag=!hold_started] run function the_hold:spawn
execute as @a[tag=hold_started] unless entity @s[x=-19,y=236,z=-16,dx=116,dy=18,dz=32] run function the_hold:return
gamemode adventure @a[tag=hold_started,gamemode=!adventure]
effect give @a[tag=hold_started] minecraft:saturation 2 0 true
