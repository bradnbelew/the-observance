clear @s
effect clear @s
gamemode adventure @s
tp @s -12.5 240 0.5 -90 0
spawnpoint @s -12 240 0
tag @s add hold_started
title @s times 20 70 30
title @s subtitle {text:"North service annex / closed June 2012",color:"dark_gray"}
title @s title {text:"COPPERLINE HOSTING",color:"gray"}
