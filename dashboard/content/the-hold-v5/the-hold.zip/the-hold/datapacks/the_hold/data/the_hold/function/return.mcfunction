gamemode adventure @s
tp @s -12.5 240 0.5 -90 0
title @s actionbar {text:"The exterior doors are sealed.",color:"dark_gray"}
